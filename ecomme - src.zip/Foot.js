import React from 'react';

const Foot = () => {
  return (
    <footer className="bg-primary text-white text-center py-5 mt-5">
      <div className="container">
        <div className="row">
          <div className="col-md-4">
            <h5>Contact Information</h5>
            <p>Email: abinayaabi2223@gmail.com</p>
            <p>Phone: +91 8870126382</p>
          </div>
          <div className="col-md-4">
            <h5>Follow Us</h5>
            <p>
              <a href="#" className="text-white">Facebook</a>
            </p>
            <p>
              <a href="#" className="text-white">Twitter</a>
            </p>
            <p>
              <a href="#" className="text-white">Instagram</a>
            </p>
          </div>
          <div className="col-md-4">
            <h5>Newsletter</h5>
            <p>Subscribe to our newsletter for updates and promotions.</p>
            <form>
              <div className="input-group">
                <input type="email" className="form-control" placeholder="Enter your email" />
                <div className="input-group-append">
                  <button className="btn btn-light" type="button">Subscribe</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div className="mt-5">
        <p>&copy; 2024 Abi Shop. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Foot;
