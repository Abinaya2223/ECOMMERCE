import React, { useState } from 'react';
import Product from './Product';

const products = [
  {
    img: 'photos/web5.jpg',
    Product: 'Product 1',
    Price: '$230',
    Description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed et nisl vel odio sollicitudin rhoncus. Proin bibendum ac justo eu volutpat.',
  },
  {
    img: 'photos/bird.jpg',
    Product: 'Product 2',
    Price: '$330',
    Description: 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In hac habitasse platea dictumst.',
  },
  {
    img: 'photos/web4.jpg',
    Product: 'Product 3',
    Price: '$30',
    Description: 'Fusce id massa nec urna facilisis gravida nec id dolor. Integer euismod, purus nec scelerisque ultricies, massa libero iaculis justo.',
  },
  {
    img: 'photos/hotel6.jpg',
    Product: 'Product 4',
    Price: '$23',
    Description: 'Aliquam erat volutpat. Sed tincidunt, tortor nec auctor sagittis, velit ligula varius neque, eu condimentum purus quam vel neque.',
  },
  {
    img: 'photos/web8.jpg',
    Product: 'Product 5',
    Price: '$230',
    Description: 'Vestibulum quis fermentum nisi. Praesent at arcu nec purus sollicitudin finibus a ut turpis. Quisque vel tincidunt velit.',
  },
  {
    img: '/photos/web3.jpg',
    Product: 'Product 6',
    Price: '$23330',
    Description: 'Nam sagittis augue vel augue bibendum, id vulputate justo eleifend. Curabitur auctor urna id sapien elementum, a volutpat purus bibendum.',
  },
  {
    img: 'photos/hotel4.jpg',
    Product: 'Product 7',
    Price: '$250',
    Description: 'Donec ac mi vel nisi varius bibendum. Morbi sem felis, euismod vel feugiat nec, suscipit at sapien. Nulla facilisi.',
  },
  {
    img: 'photos/hotel7.jpg',
    Product: 'Product 8',
    Price: '$300',
    Description: 'Vivamus feugiat, dolor ac dictum finibus, erat augue efficitur velit, ac rhoncus orci odio et turpis. In hac habitasse platea dictumst.',
  },
  {
    img: 'photos/hotel8.jpg',
    Product: 'Product 9',
    Price: '$40',
    Description: 'Integer gravida velit at urna efficitur, in fermentum dolor fermentum. Proin ac sem sit amet dui hendrerit luctus.',
  },
  {
    img: 'photos/hotel12.jpg',
    Product: 'Product 10',
    Price: '$27',
    Description: 'Suspendisse potenti. Sed at lacus ac nunc fermentum pharetra. Sed condimentum, purus id consectetur sagittis, purus justo efficitur neque.',
  },
  {
    img: 'photos/hotel5.jpg',
    Product: 'Product 11',
    Price: '$240',
    Description: 'Ut bibendum ullamcorper erat a bibendum. Fusce nec metus id mauris luctus bibendum ac id elit. Maecenas scelerisque facilisis neque vel rhoncus.',
  },
  {
    img: 'photos/hotel3.jpg',
    Product: 'Product 12',
    Price: '$23500',
    Description: 'Nunc et urna eu ante varius auctor id in nunc. In sed rhoncus metus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae.',
  },
  {
    img: 'photos/hotel9.jpg',
    Product: 'Product 13',
    Price: '$240',
    Description: 'Sed ac metus vel purus facilisis sollicitudin. Phasellus efficitur est vel dapibus laoreet. Suspendisse ac cursus sem.',
  },
  {
    img: 'photos/hotel2.jpg',
    Product: 'Product 14',
    Price: '$23500',
    Description: 'Mauris bibendum nunc sed ullamcorper convallis. Duis id efficitur eros. Sed in turpis libero. Nullam sit amet malesuada ex, vitae efficitur justo.',
  },
  {
    img: 'photos/hotel1.jpg',
    Product: 'Product 15',
    Price: '$23500',
    Description: 'Vestibulum in elit nec erat facilisis scelerisque. Integer aliquet elit in felis bibendum, in luctus mi posuere.',
  },
]

const productsPerPage = 6;

const Main = ({ addToCart }) => {
  const [displayedProducts, setDisplayedProducts] = useState(productsPerPage);

  const handleLoadMoreClick = () => {
    setDisplayedProducts(displayedProducts + productsPerPage);
  };

  const handleLoadLessClick = () => {
    setDisplayedProducts(productsPerPage);
  };

  return (
    <div className="container mt-5 pt-4 overflow-auto">
      <div className="row">
        {products.slice(0, displayedProducts).map((product, index) => (
          <div className="col-md-4 mb-4" key={index}>
            <div className="card">
              <img src={product.img} className="card-img-top" alt={product.Product} />
              <div className="card-body">
                <h5 className="card-title">{product.Product}</h5>
                <p className="card-text">${product.Price}</p>
                {/* Additional content for each product */}
                <p className="card-text text-muted">{product.Description || 'No description available'}</p>
                <button className="btn btn-primary" onClick={() => addToCart(product)}>
                  Add to Cart
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="text-center mt-3">
        {displayedProducts < products.length ? (
          <button className="btn btn-primary" onClick={handleLoadMoreClick}>
            Load More
          </button>
        ) : (
          <button className="btn btn-primary" onClick={handleLoadLessClick}>
            Load Less
          </button>
        )}
      </div>
    </div>
  );
};

export default Main;