import React from 'react';
import './Product.css';

const Product = (props) => {
  const { img, Product, Price, addToCart } = props;

  return (
    <div className='Product card'>
      <img src={img} className='card-img-top' alt="It's a beautiful pic" />
      <div className='card-body'>
        <h3 className='card-title'>{Product}</h3>
        <h4 className='card-text'>{Price}</h4>
        <button className='btn btn-danger' onClick={() => addToCart(props)}>Buy Now</button>
      </div>
    </div>
  );
}

export default Product;
