// Head.js
import React, { useState } from 'react';
import CartIcon from './CartIcon';
import CartDropdown from './CartDropdown';

const Head = ({ cart }) => {
  const [selectedProduct, setSelectedProduct] = useState(null);

  const handleProductClick = (product) => {
    setSelectedProduct(product);
  };

  const closeProductModal = () => {
    setSelectedProduct(null);
  };

  return (
    <header className="py-3 mb-3 fixed-top">
      <div className="container">
        {selectedProduct && (
          <div className="modal" role="dialog" style={{ display: 'block' }}>
            <div className="modal-dialog" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title">{selectedProduct.Product}</h5>
                  <button type="button" className="close" onClick={closeProductModal}>
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div className="modal-body">
                  <img src={selectedProduct.img} alt={selectedProduct.Product} className="img-fluid" />
                  <p>${selectedProduct.Price}</p>
                  {/* Additional Content */}
                  <p>{selectedProduct.Description}</p>
                  <p>Rating: {selectedProduct.Rating}</p>
                  {/* Add more content as needed */}
                </div>
              </div>
            </div>
          </div>
        )}

        <nav className="navbar navbar-expand-md navbar-light">
          <div className="container">
            <a className="navbar-brand" href="#">
              Abi Shop
            </a>
            <button
              className="navbar-toggler"
              type="button"
              data-toggle="collapse"
              data-target="#navbarNav"
              aria-controls="navbarNav"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse justify-content-end" id="navbarNav">
              <ul className="navbar-nav">
                <li className="nav-item active">
                  <a className="nav-link" href="#">
                    Home
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">
                    About
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">
                    Products
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">
                    Help
                  </a>
                </li>
                <CartDropdown cart={cart} handleProductClick={handleProductClick} />
                <CartIcon cart={cart} />
              </ul>
            </div>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Head;
