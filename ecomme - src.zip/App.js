// App.js
import React, { useState } from 'react';
import Head from './Head';
import Foot from './Foot';
import Main from './Main';

function App() {
  const [cart, setCart] = useState([]);

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  return (
    <div className='bg-gradient'>
      <Head cart={cart} />
      <div className="container mt-6">
        <Main addToCart={addToCart} />
      </div>
      <Foot />
    </div>
  );
}

export default App;
