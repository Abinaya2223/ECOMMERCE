import React from 'react';

const CartIcon = ({ cart }) => {
  const cartQuantity = cart.length;

  return (
    <div className="cart-icon ml-20"> {/* Add ml-auto class for left positioning */}
      <i className="fas fa-shopping-cart fa-lg"></i>
      <span className="cart-quantity badge badge-pill badge-primary">{cartQuantity}</span>
    </div>
  );
};

export default CartIcon;
