import React, { useState } from 'react';

const CartDropdown = ({ cart, handleProductClick }) => {
  const calculateTotalPrice = () => {
    if (Array.isArray(cart) && cart.length > 0) {
      const total = cart.reduce((acc, item) => acc + parseFloat(item.Price), 0);
      return total.toFixed(2);
    }
    return '0.00'; // Default value if cart is empty or invalid
  };

  const toggleDropdown = () => {
    const dropdownToggle = document.getElementById('cartDropdown');
    const dropdownMenu = document.querySelector('.cart-dropdown .dropdown-menu');

    if (dropdownToggle && dropdownMenu) {
      dropdownMenu.classList.toggle('show');
    }
  };

  return (
    <div className="dropdown cart-dropdown ml-auto">
      <button
        className="btn btn-secondary dropdown-toggle"
        id="cartDropdown"
        onClick={toggleDropdown}
        aria-haspopup="true"
        aria-expanded="false"
      >
        View Cart
      </button>
      <div className="dropdown-menu wd" aria-labelledby="cartDropdown" style={{ maxHeight: '400px', overflowY: 'auto', maxWidth: '300px' }}>
        <div className="cart-details p-3">
          <h5 className="dropdown-header">Shopping Cart</h5>
          <ul className="list-group">
            {Array.isArray(cart) && cart.length > 0 ? (
              cart.map((item, index) => (
                <li key={index} onClick={() => handleProductClick(item)} className="list-group-item">
                  <div className="cart-item d-flex justify-content-between align-items-center">
                    <div className="cart-item-details">
                      <h6 className="mb-1">{item.Product}</h6>
                      <p className="mb-1">${item.Price}</p>
                      <p className="text-muted">{item.Description}</p>
                      <p className="mb-0">Quantity: {item.Quantity || 1}</p>
                    </div>
                    {/* Uncomment the image tag when images are available */}
                    {/* <img src={item.img} alt={item.Product} className="cart-item-img" /> */}
                  </div>
                </li>
              ))
            ) : (
              <li className="list-group-item text-center">Your cart is empty.</li>
            )}
          </ul>
          <div className="dropdown-divider mt-3 mb-3"></div>
          <div className="cart-summary">
            <p className="mb-1">Total Items: {cart.length}</p>
            <p>Total Price: ${calculateTotalPrice()}</p>
          </div>
          <button className="btn btn-primary btn-block mt-3">Proceed to Checkout</button>
        </div>
      </div>
    </div>
  );
};

export default CartDropdown;
